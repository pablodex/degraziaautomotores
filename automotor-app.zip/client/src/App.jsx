import { useEffect, useState } from "react";
import axios from "axios";

const API = import.meta.env.VITE_API_URL;

function App() {
  const [ventas, setVentas] = useState([]);

  useEffect(() => {
    axios.get(`${API}/ventas`).then((res) => setVentas(res.data));
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Ventas Registradas</h1>
      <ul className="space-y-2">
        {ventas.map((venta) => (
          <li key={venta.id} className="border p-2 rounded">
            {venta.cliente} compró un {venta.vehiculo} por ${venta.precio}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
