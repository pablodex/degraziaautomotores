const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

// Crear tablas si no existen
pool.query(`
  CREATE TABLE IF NOT EXISTS ventas (
    id SERIAL PRIMARY KEY,
    cliente TEXT NOT NULL,
    vehiculo TEXT NOT NULL,
    precio NUMERIC,
    fecha DATE DEFAULT CURRENT_DATE
  );

  CREATE TABLE IF NOT EXISTS cuotas (
    id SERIAL PRIMARY KEY,
    venta_id INTEGER REFERENCES ventas(id),
    numero INTEGER,
    monto NUMERIC,
    pagado BOOLEAN DEFAULT false,
    fecha_pago DATE
  );
`);

// Rutas
app.get("/ventas", async (req, res) => {
  const result = await pool.query("SELECT * FROM ventas ORDER BY id DESC");
  res.json(result.rows);
});

app.post("/ventas", async (req, res) => {
  const { cliente, vehiculo, precio } = req.body;
  const result = await pool.query(
    "INSERT INTO ventas (cliente, vehiculo, precio) VALUES ($1, $2, $3) RETURNING *",
    [cliente, vehiculo, precio]
  );
  res.json(result.rows[0]);
});

app.post("/cuotas", async (req, res) => {
  const { venta_id, numero, monto } = req.body;
  const result = await pool.query(
    "INSERT INTO cuotas (venta_id, numero, monto) VALUES ($1, $2, $3) RETURNING *",
    [venta_id, numero, monto]
  );
  res.json(result.rows[0]);
});

app.patch("/cuotas/:id/pagar", async (req, res) => {
  const { id } = req.params;
  const result = await pool.query(
    "UPDATE cuotas SET pagado = true, fecha_pago = CURRENT_DATE WHERE id = $1 RETURNING *",
    [id]
  );
  res.json(result.rows[0]);
});

app.listen(process.env.PORT || 3001, () => {
  console.log("Servidor escuchando en el puerto 3001");
});
